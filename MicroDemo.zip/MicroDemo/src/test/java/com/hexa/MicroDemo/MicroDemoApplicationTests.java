package com.hexa.MicroDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
