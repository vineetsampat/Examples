function edit_row(no)
{
 document.getElementById("edit_button"+no).style.display="none";
 document.getElementById("save_button"+no).style.display="block";
	
 var reqid=document.getElementById("reqid_row"+no);
 var rr=document.getElementById("rr_row"+no);
 var skills=document.getElementById("skills_row"+no);
 var prty=document.getElementById("prty_row"+no);
 var jblvl=document.getElementById("jblvl_row"+no);
 var enddate=document.getElementById("enddate_row"+no);
	
 var reqid_data=reqid.innerHTML;
 var rr_data=rr.innerHTML;
 var skills_data=skills.innerHTML;
 var prty_data=prty.innerHTML;
 var jblvl_data=jblvl.innerHTML;
 var enddate_data=enddate.innerHTML;
	
 reqid.innerHTML="<input type='text' id='reqid_text"+no+"' value='"+reqid_data+"'>";
 rr.innerHTML="<input type='text' id='rr_text"+no+"' value='"+rr_data+"'>";
 skills.innerHTML="<input type='text' id='skills_text"+no+"' value='"+skills_data+"'>";
 prty.innerHTML="<input type='text' id='prty_text"+no+"' value='"+prty_data+"'>";
 jblvl.innerHTML="<input type='text' id='jblvl_text"+no+"' value='"+jblvl_data+"'>";
 enddate.innerHTML="<input type='date' id='enddate_date"+no+"' value='"+enddate_data+"'>";

}

function save_row(no)
{

 var reqid_val=document.getElementById("reqid_text"+no).value;
 var rr_val=document.getElementById("rr_text"+no).value;
 var skills_val=document.getElementById("skills_text"+no).value;
 var prty_val=document.getElementById("prty_text"+no).value;
 var jblvl_val=document.getElementById("jblvl_text"+no).value;
 var enddate_val=document.getElementById("enddate_date"+no).value;

 document.getElementById("reqid_row"+no).innerHTML=reqid_val;
 document.getElementById("rr_row"+no).innerHTML=rr_val;
 document.getElementById("skills_row"+no).innerHTML=skills_val;
 document.getElementById("prty_row"+no).innerHTML=prty_val;
 document.getElementById("jblvl_row"+no).innerHTML=jblvl_val;
 document.getElementById("enddate_row"+no).innerHTML=enddate_val;

 document.getElementById("edit_button"+no).style.display="block";
 document.getElementById("save_button"+no).style.display="none";
}

function delete_row(no)
{
 document.getElementById("row"+no+"").outerHTML="";
}

function add_row()
{
 var new_reqid=document.getElementById("new_reqid").value;
 var new_rr=document.getElementById("new_rr").value;
 var new_skills=document.getElementById("new_skills").value;
 var new_prty=document.getElementById("new_prty").value;
 var new_jblvl=document.getElementById("new_jblvl").value;
 var new_enddate=document.getElementById("new_enddate").value;
	
 var table=document.getElementById("data_table");
 var table_len=(table.rows.length)-1;
 var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='reqid_row"+table_len+"'>"+new_reqid+"</td><td id='rr_row"+table_len+"'>"+new_rr+"</td><td id='skills_row"+table_len+"'>"+new_skills+"</td><td id='prty_row"+table_len+"'>"+new_prty+"</td><td id='jblvl_row"+table_len+"'>"+new_jblvl+"</td><td id='enddate_row"+table_len+"'>"+new_enddate+"</td><td><input type='button' id='edit_button"+table_len+"' value='Edit' class='edit' onclick='edit_row("+table_len+")'> <input type='button' id='save_button"+table_len+"' value='Save' class='save' onclick='save_row("+table_len+")'> <input type='button' value='Delete' class='delete' onclick='delete_row("+table_len+")'></td></tr>";

 document.getElementById("new_reqid").value="";
 document.getElementById("new_rr").value="";
 document.getElementById("new_skills").value="";
 document.getElementById("new_prty").value="";
 document.getElementById("new_jblvl").value="";
 document.getElementById("new_enddate").value="";
}