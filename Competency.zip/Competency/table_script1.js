function edit_row(no)
{
 document.getElementById("edit_button"+no).style.display="none";
 document.getElementById("save_button"+no).style.display="block";
	
 var intid=document.getElementById("intid_row"+no);
 var intvenm=document.getElementById("intvenm_row"+no);
 var intvemail=document.getElementById("intvemail_row"+no);
 var intvrnm=document.getElementById("intvrnm_row"+no);
 var intvrmail=document.getElementById("intvrmail_row"+no);
 var intvwdate=document.getElementById("intvwdate_row"+no);
 var intvcmts=document.getElementById("intvcmts_row"+no);
 var intvlink=document.getElementById("intvlink_row"+no);
	
 var intid_data=intid.innerHTML;
 var intvenm_data=intvenm.innerHTML;
 var intvemail_data=intvemail.innerHTML;
 var intvrnm_data=intvrnm.innerHTML;
 var intvrmail_data=intvrmail.innerHTML;
 var intvwdate_data=intvwdate.innerHTML;
 var intvcmts_data=intvcmts.innerHTML;
 var intvlink_data=intvlink.innerHTML;
	
 intid.innerHTML="<input type='text' id='intid_text"+no+"' value='"+intid_data+"'>";
 intvenm.innerHTML="<input type='text' id='intvenm_text"+no+"' value='"+intvenm_data+"'>";
 intvemail.innerHTML="<input type='text' id='intvemail_text"+no+"' value='"+intvemail_data+"'>";
 intvrnm.innerHTML="<input type='text' id='intvrnm_text"+no+"' value='"+intvrnm_data+"'>";
 intvrmail.innerHTML="<input type='text' id='intvrmail_text"+no+"' value='"+intvrmail_data+"'>";
 intvwdate.innerHTML="<input type='date' id='intvwdate_date"+no+"' value='"+intvwdate_data+"'>";
 intvcmts.innerHTML="<input type='text' id='intvcmts_text"+no+"' value='"+intvcmts_data+"'>";
 intvlink.innerHTML="<input type='url' id='intvlink_url"+no+"' value='"+intvlink_data+"'>";

}

function save_row(no)
{

 var intid_val=document.getElementById("intid_text"+no).value;
 var intvenm_val=document.getElementById("intvenm_text"+no).value;
 var intvemail_val=document.getElementById("intvemail_text"+no).value;
 var intvrnm_val=document.getElementById("intvrnm_text"+no).value;
 var intvrmail_val=document.getElementById("intvrmail_text"+no).value;
 var intvwdate_val=document.getElementById("intvwdate_date"+no).value;
 var intvcmts_val=document.getElementById("intvcmts_text"+no).value;
 var intvlink_val=document.getElementById("intvlink_url"+no).value;

 document.getElementById("intid_row"+no).innerHTML=intid_val;
 document.getElementById("intvenm_row"+no).innerHTML=intvenm_val;
 document.getElementById("intvemail_row"+no).innerHTML=intvemail_val;
 document.getElementById("intvrnm_row"+no).innerHTML=intvrnm_val;
 document.getElementById("intvrmail_row"+no).innerHTML=intvrmail_val;
 document.getElementById("intvwdate_row"+no).innerHTML=intvwdate_val;
 document.getElementById("intvcmts_row"+no).innerHTML=intvcmts_val;
 document.getElementById("intvlink_row"+no).innerHTML=intvlink_val;

 document.getElementById("edit_button"+no).style.display="block";
 document.getElementById("save_button"+no).style.display="none";
}

function delete_row(no)
{
 document.getElementById("row"+no+"").outerHTML="";
}

function add_row()
{
 var new_intid=document.getElementById("new_intid").value;
 var new_intvenm=document.getElementById("new_intvenm").value;
 var new_intvemail=document.getElementById("new_intvemail").value;
 var new_intvrnm=document.getElementById("new_intvrnm").value;
 var new_intvrmail=document.getElementById("new_intvrmail").value;
 var new_intvwdate=document.getElementById("new_intvwdate").value;
 var new_intvcmts=document.getElementById("new_intvcmts").value;
 var new_intvlink=document.getElementById("new_intvlink").value;
	
 var table=document.getElementById("data_table");
 var table_len=(table.rows.length)-1;
 var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='intid_row"+table_len+"'>"+new_intid+"</td><td id='intvenm_row"+table_len+"'>"+new_intvenm+"</td><td id='intvemail_row"+table_len+"'>"+new_intvemail+"</td><td id='intvrnm_row"+table_len+"'>"+new_intvrnm+"</td><td id='intvrmail_row"+table_len+"'>"+new_intvrmail+"</td><td id='intvwdate_row"+table_len+"'>"+new_intvwdate+"</td><td id='intvcmts_row"+table_len+"'>"+new_intvcmts+"</td><td id='intvlink_row"+table_len+"'>"+new_intvlink+"</td><td><input type='button' id='edit_button"+table_len+"' value='Edit' class='edit' onclick='edit_row("+table_len+")'> <input type='button' id='save_button"+table_len+"' value='Save' class='save' onclick='save_row("+table_len+")'> <input type='button' value='Delete' class='delete' onclick='delete_row("+table_len+")'></td></tr>";

 document.getElementById("new_intid").value="";
 document.getElementById("new_intvenm").value="";
 document.getElementById("new_intvemail").value="";
 document.getElementById("new_intvrnm").value="";
 document.getElementById("new_intvrmail").value="";
 document.getElementById("new_intvwdate").value="";
 document.getElementById("new_intvcmts").value="";
 document.getElementById("new_intvlink").value="";
}